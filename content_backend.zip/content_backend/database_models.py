"""
SQLAlchemy database models for the Coastal Threat Alert System.
These models define the database schema and table structures.
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class GDACSEvent(Base):
    """GDACS disaster event model for real-time disaster alerts."""
    __tablename__ = "gdacs_events"
    
    id = Column(String(50), primary_key=True, index=True)  # GDACS event ID like EQ1498040
    iso3 = Column(String(10), nullable=True)  # Country code
    country = Column(String(255), nullable=True)  # Country name
    title = Column(Text, nullable=False)  # Event title
    summary = Column(Text, nullable=False)  # Detailed description
    event_type = Column(String(100), nullable=False)  # Earthquake, Tropical Cyclone, Wildfire, Flood
    severity_unit = Column(String(50), nullable=True)  # M, km/h, ha, etc.
    severity_value = Column(Float, nullable=True)  # Numeric severity value
    source = Column(String(255), nullable=False)  # Data source
    from_date = Column(DateTime, nullable=False)  # Start date
    to_date = Column(DateTime, nullable=False)  # End date
    link = Column(Text, nullable=False)  # GDACS report URL
    geo_lat = Column(Float, nullable=False)  # Latitude
    geo_long = Column(Float, nullable=False)  # Longitude
    gdacs_bbox = Column(Text, nullable=True)  # Geographic bounding box
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Computed fields for threat assessment
    threat_level = Column(String(50), nullable=True)  # Green, Orange, Red
    population_affected = Column(Integer, nullable=True)  # Estimated affected population
    economic_impact = Column(String(100), nullable=True)  # Economic impact category

class Sensor(Base):
    """Sensor model for environmental monitoring devices."""
    __tablename__ = "sensors"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    location = Column(String(500), nullable=False)
    sensor_type = Column(String(100), nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    readings = relationship("Reading", back_populates="sensor")
    incidents = relationship("Incident", back_populates="sensor")

class Reading(Base):
    """Sensor reading model for environmental data."""
    __tablename__ = "readings"
    
    id = Column(Integer, primary_key=True, index=True)
    sensor_id = Column(Integer, ForeignKey("sensors.id"), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    value = Column(Float, nullable=False)
    unit = Column(String(50), nullable=False)
    quality_score = Column(Float, default=1.0)
    
    # Relationships
    sensor = relationship("Sensor", back_populates="readings")

class Incident(Base):
    """Incident model for detected threats and anomalies."""
    __tablename__ = "incidents"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    incident_type = Column(String(100), nullable=False)
    severity_level = Column(String(50), nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    detected_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_resolved = Column(Boolean, default=False)
    resolved_at = Column(DateTime, nullable=True)
    sensor_id = Column(Integer, ForeignKey("sensors.id"), nullable=True)
    gdacs_event_id = Column(String(50), ForeignKey("gdacs_events.id"), nullable=True)  # Link to GDACS event
    
    # Relationships
    sensor = relationship("Sensor", back_populates="incidents")
    alerts = relationship("Alert", back_populates="incident")
    gdacs_event = relationship("GDACSEvent")

class Alert(Base):
    """Alert model for notifications and warnings."""
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    incident_id = Column(Integer, ForeignKey("incidents.id"), nullable=False)
    alert_type = Column(String(100), nullable=False)  # email, sms, push_notification
    message = Column(Text, nullable=False)
    priority = Column(String(50), nullable=False)  # low, medium, high, urgent
    sent_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    is_sent = Column(Boolean, default=False)
    recipient = Column(String(255), nullable=False)
    
    # Relationships
    incident = relationship("Incident", back_populates="alerts")

class ThreatScore(Base):
    """Threat score model for risk assessment."""
    __tablename__ = "threat_scores"
    
    id = Column(Integer, primary_key=True, index=True)
    location_name = Column(String(255), nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    score = Column(Float, nullable=False)  # 0-100 scale
    factors = Column(Text, nullable=False)  # JSON string of factors
    calculated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    valid_until = Column(DateTime, nullable=False)
    confidence_level = Column(Float, default=1.0)  # 0-1 scale
    gdacs_events_count = Column(Integer, default=0)  # Number of nearby GDACS events

# Additional models for future use
class User(Base):
    """User model for authentication and authorization."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Notification(Base):
    """Notification model for user alerts."""
    __tablename__ = "notifications"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    notification_type = Column(String(100), nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User")

# Database indexes for better performance
from sqlalchemy import Index

# Create indexes for common queries
Index('idx_gdacs_events_type_date', GDACSEvent.event_type, GDACSEvent.from_date)
Index('idx_gdacs_events_location', GDACSEvent.geo_lat, GDACSEvent.geo_long)
Index('idx_gdacs_events_country', GDACSEvent.country)
Index('idx_sensors_location', Sensor.latitude, Sensor.longitude)
Index('idx_readings_sensor_timestamp', Reading.sensor_id, Reading.timestamp)
Index('idx_incidents_type_severity', Incident.incident_type, Incident.severity_level)
Index('idx_alerts_incident_type', Alert.incident_id, Alert.alert_type)
Index('idx_threat_scores_location', ThreatScore.latitude, ThreatScore.longitude)

# Coastal Threat Alert System - FastAPI Backend

A comprehensive FastAPI backend system for monitoring coastal threats and environmental conditions. This system provides real-time monitoring, threat detection, and alert management for coastal areas.

## 🚀 Features

- **Sensor Management**: CRUD operations for environmental sensors
- **Data Collection**: Real-time sensor readings and data management
- **Threat Detection**: Anomaly detection and incident management
- **Alert System**: Multi-channel notification system (email, SMS, push)
- **Risk Assessment**: Threat scoring and risk analysis
- **Computer Vision**: Image and video analysis for coastal monitoring
- **RESTful API**: Comprehensive REST API with automatic documentation

## 🏗️ Project Structure

```
coastal_threat_backend/
├── requirements.txt          # Python dependencies
├── env.sample               # Environment variables template
├── db.py                    # Database connection and session management
├── database_models.py       # SQLAlchemy database models
├── models.py                # Pydantic API models
├── main.py                  # FastAPI application entry point
├── services/                # Business logic services
│   ├── __init__.py
│   ├── anomaly.py           # Anomaly detection service
│   └── vision.py            # Computer vision service
└── routes/                  # API route modules
    ├── __init__.py
    ├── sensors.py           # Sensor management endpoints
    ├── readings.py          # Sensor data endpoints
    ├── incidents.py         # Incident management endpoints
    ├── alerts.py            # Alert system endpoints
    └── score.py             # Threat scoring endpoints
```

## 🛠️ Installation & Setup

### Prerequisites

- Python 3.8 or higher
- pip (Python package installer)

### 1. Clone and Navigate to Project

```bash
cd coastal_threat_backend
```

### 2. Create Virtual Environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Environment Configuration

Copy the environment template and configure your settings:

```bash
# Windows
copy env.sample .env

# macOS/Linux
cp env.sample .env
```

Edit `.env` file with your configuration:

```env
# Database Configuration
DATABASE_URL=sqlite:///./coastal_threat.db

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=True

# Security
SECRET_KEY=your-secret-key-here-change-in-production
```

## 🚀 Running the Application

### Option 1: Using uvicorn directly

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### Option 2: Using Python main.py

```bash
python main.py
```

### Option 3: Using the requirements.txt uvicorn

```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## 📚 API Documentation

Once the server is running, you can access:

- **Interactive API Docs (Swagger UI)**: http://localhost:8000/docs
- **Alternative API Docs (ReDoc)**: http://localhost:8000/redoc
- **API Root**: http://localhost:8000/
- **Health Check**: http://localhost:8000/health

## 🧪 Testing the Endpoints

### 1. Health Check

```bash
curl http://localhost:8000/health
```

### 2. Get All Sensors

```bash
curl http://localhost:8000/api/v1/sensors
```

### 3. Get Sensor by ID

```bash
curl http://localhost:8000/api/v1/sensors/1
```

### 4. Create a New Sensor

```bash
curl -X POST "http://localhost:8000/api/v1/sensors/" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "New Water Sensor",
    "location": "Beach Front",
    "sensor_type": "water_level",
    "latitude": 40.7000,
    "longitude": -74.0000,
    "is_active": true
  }'
```

### 5. Get Sensor Readings

```bash
curl http://localhost:8000/api/v1/readings
```

### 6. Get Incidents

```bash
curl http://localhost:8000/api/v1/incidents
```

### 7. Get Alerts

```bash
curl http://localhost:8000/api/v1/alerts
```

### 8. Get Threat Scores

```bash
curl http://localhost:8000/api/v1/score
```

### 9. Calculate New Threat Score

```bash
curl -X POST "http://localhost:8000/api/v1/score/calculate" \
  -H "Content-Type: application/json" \
  -d '{
    "latitude": 40.7000,
    "longitude": -74.0000,
    "location_name": "Test Location"
  }'
```

## 🔧 API Endpoints Overview

### Sensors (`/api/v1/sensors`)
- `GET /` - List all sensors
- `GET /{id}` - Get sensor by ID
- `POST /` - Create new sensor
- `PUT /{id}` - Update sensor
- `DELETE /{id}` - Delete sensor
- `GET /types/{type}` - Get sensors by type
- `GET /location/nearby` - Find sensors near coordinates

### Readings (`/api/v1/readings`)
- `GET /` - List all readings
- `GET /{id}` - Get reading by ID
- `POST /` - Create new reading
- `GET /sensor/{id}/latest` - Get latest reading for sensor
- `GET /sensor/{id}/history` - Get sensor history
- `GET /sensor/{id}/statistics` - Get sensor statistics

### Incidents (`/api/v1/incidents`)
- `GET /` - List all incidents
- `GET /{id}` - Get incident by ID
- `POST /` - Create new incident
- `PUT /{id}` - Update incident
- `DELETE /{id}` - Delete incident
- `POST /{id}/resolve` - Mark incident as resolved
- `GET /types/statistics` - Get incident statistics

### Alerts (`/api/v1/alerts`)
- `GET /` - List all alerts
- `GET /{id}` - Get alert by ID
- `POST /` - Create new alert
- `POST /{id}/send` - Mark alert as sent
- `GET /incident/{id}` - Get alerts for incident
- `GET /priority/{level}` - Get alerts by priority
- `POST /bulk/create` - Create multiple alerts

### Threat Scores (`/api/v1/score`)
- `GET /` - List all threat scores
- `GET /{id}` - Get threat score by ID
- `POST /` - Create new threat score
- `POST /calculate` - Calculate new threat score
- `GET /location/{name}` - Get scores by location
- `GET /statistics/summary` - Get score statistics
- `POST /bulk/calculate` - Calculate scores for multiple locations

## 🎯 Key Features

### Dummy Data for Immediate Testing
All endpoints return realistic dummy data, so you can test the API immediately without setting up a database.

### Comprehensive Error Handling
Custom error handlers for 404 and 500 errors with helpful messages and available endpoints.

### CORS Support
Configured to allow cross-origin requests for frontend development.

### Automatic API Documentation
FastAPI automatically generates interactive API documentation from your code and docstrings.

### Database Integration Ready
Includes SQLAlchemy models and database setup for easy transition to real database.

## 🔮 Future Enhancements

- Real-time WebSocket connections for live data streaming
- Authentication and authorization system
- Rate limiting and API key management
- Integration with external weather APIs
- Machine learning models for improved threat detection
- Mobile app API endpoints
- Webhook support for external integrations

## 🐛 Troubleshooting

### Common Issues

1. **Port already in use**: Change the port in `.env` file or kill the process using the port
2. **Import errors**: Ensure all dependencies are installed and virtual environment is activated
3. **Database errors**: The system uses SQLite by default, which should work out of the box

### Debug Mode

Set `DEBUG=True` in your `.env` file to enable debug mode with auto-reload.

## 📝 Development Notes

- All endpoints use dummy data for immediate functionality
- Database models are defined but not actively used (in-memory data)
- Services contain dummy logic that can be replaced with real implementations
- The system is designed to be easily extensible

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Check the API documentation at `/docs`
- Review the code comments
- Open an issue in the repository

---

**Happy coding! 🚀**

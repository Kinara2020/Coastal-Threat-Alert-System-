"""
Pydantic models for the Coastal Threat Alert System API.
These models define the data structures for API requests and responses.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

# Base models for common fields
class TimestampMixin(BaseModel):
    """Mixin for timestamp fields."""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class LocationMixin(BaseModel):
    """Mixin for location fields."""
    latitude: float = Field(..., ge=-90, le=90, description="Latitude coordinate")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude coordinate")

# GDACS Event models (NEW - replacing old dummy data)
class GDACSEventBase(BaseModel):
    """Base GDACS event model."""
    id: str = Field(..., description="GDACS event identifier")
    iso3: Optional[str] = Field(None, description="Country code")
    country: Optional[str] = Field(None, description="Country name")
    title: str = Field(..., description="Event title")
    summary: str = Field(..., description="Detailed description")
    event_type: str = Field(..., description="Type of disaster event")
    severity_unit: Optional[str] = Field(None, description="Unit of severity measurement")
    severity_value: Optional[float] = Field(None, description="Numeric severity value")
    source: str = Field(..., description="Data source")
    from_date: datetime = Field(..., description="Event start date")
    to_date: datetime = Field(..., description="Event end date")
    link: str = Field(..., description="GDACS report URL")
    geo_lat: float = Field(..., ge=-90, le=90, description="Latitude coordinate")
    geo_long: float = Field(..., ge=-180, le=180, description="Longitude coordinate")
    gdacs_bbox: Optional[str] = Field(None, description="Geographic bounding box")

class GDACSEventCreate(GDACSEventBase):
    """Model for creating a new GDACS event."""
    pass

class GDACSEvent(GDACSEventBase, TimestampMixin):
    """Complete GDACS event model."""
    threat_level: Optional[str] = Field(None, description="Threat level (Green, Orange, Red)")
    population_affected: Optional[int] = Field(None, description="Estimated affected population")
    economic_impact: Optional[str] = Field(None, description="Economic impact category")
    
    class Config:
        from_attributes = True

# Sensor models
class SensorBase(BaseModel):
    """Base sensor model."""
    name: str = Field(..., min_length=1, max_length=255, description="Sensor name")
    location: str = Field(..., min_length=1, max_length=500, description="Sensor location description")
    sensor_type: str = Field(..., description="Type of sensor (e.g., water_level, wind_speed)")
    latitude: float = Field(..., ge=-90, le=90, description="Latitude coordinate")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude coordinate")
    is_active: bool = Field(True, description="Whether the sensor is active")

class SensorCreate(SensorBase):
    """Model for creating a new sensor."""
    pass

class SensorUpdate(BaseModel):
    """Model for updating a sensor."""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    location: Optional[str] = Field(None, min_length=1, max_length=500)
    sensor_type: Optional[str] = None
    latitude: Optional[float] = Field(None, ge=-90, le=90)
    longitude: Optional[float] = Field(None, ge=-180, le=180)
    is_active: Optional[bool] = None

class Sensor(SensorBase, TimestampMixin):
    """Complete sensor model with ID."""
    id: int = Field(..., description="Unique sensor identifier")
    
    class Config:
        from_attributes = True

# Reading models
class ReadingBase(BaseModel):
    """Base reading model."""
    sensor_id: int = Field(..., description="ID of the sensor that took this reading")
    value: float = Field(..., description="Numeric value of the reading")
    unit: str = Field(..., min_length=1, max_length=50, description="Unit of measurement")
    quality_score: float = Field(1.0, ge=0.0, le=1.0, description="Data quality score (0-1)")

class ReadingCreate(ReadingBase):
    """Model for creating a new reading."""
    pass

class Reading(ReadingBase):
    """Complete reading model with ID and timestamp."""
    id: int = Field(..., description="Unique reading identifier")
    timestamp: datetime = Field(..., description="When the reading was taken")
    
    class Config:
        from_attributes = True

# Incident models
class IncidentBase(BaseModel):
    """Base incident model."""
    title: str = Field(..., min_length=1, max_length=255, description="Incident title")
    description: str = Field(..., min_length=1, description="Detailed incident description")
    incident_type: str = Field(..., description="Type of incident (e.g., flooding, storm_damage)")
    severity_level: str = Field(..., description="Severity level (low, medium, high, critical)")
    latitude: float = Field(..., ge=-90, le=90, description="Latitude coordinate")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude coordinate")

class IncidentCreate(IncidentBase):
    """Model for creating a new incident."""
    pass

class IncidentUpdate(BaseModel):
    """Model for updating an incident."""
    title: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, min_length=1)
    incident_type: Optional[str] = None
    severity_level: Optional[str] = None
    latitude: Optional[float] = Field(None, ge=-90, le=90)
    longitude: Optional[float] = Field(None, ge=-180, le=180)
    is_resolved: Optional[bool] = None

class Incident(IncidentBase):
    """Complete incident model with ID and timestamps."""
    id: int = Field(..., description="Unique incident identifier")
    detected_at: datetime = Field(..., description="When the incident was detected")
    is_resolved: bool = Field(False, description="Whether the incident has been resolved")
    resolved_at: Optional[datetime] = Field(None, description="When the incident was resolved")
    sensor_id: Optional[int] = Field(None, description="ID of the sensor that detected the incident")
    gdacs_event_id: Optional[str] = Field(None, description="Linked GDACS event ID")
    
    class Config:
        from_attributes = True

# Alert models
class AlertBase(BaseModel):
    """Base alert model."""
    incident_id: int = Field(..., description="ID of the incident this alert is for")
    alert_type: str = Field(..., description="Type of alert (email, sms, push_notification)")
    message: str = Field(..., min_length=1, description="Alert message content")
    priority: str = Field(..., description="Alert priority (low, medium, high, urgent)")
    recipient: str = Field(..., min_length=1, max_length=255, description="Alert recipient")

class AlertCreate(AlertBase):
    """Model for creating a new alert."""
    pass

class Alert(AlertBase):
    """Complete alert model with ID and timestamps."""
    id: int = Field(..., description="Unique alert identifier")
    sent_at: datetime = Field(..., description="When the alert was sent")
    is_sent: bool = Field(False, description="Whether the alert has been sent")
    
    class Config:
        from_attributes = True

# Threat Score models
class ThreatScoreBase(BaseModel):
    """Base threat score model."""
    location_name: str = Field(..., min_length=1, max_length=255, description="Name of the location")
    latitude: float = Field(..., ge=-90, le=90, description="Latitude coordinate")
    longitude: float = Field(..., ge=-180, le=180, description="Longitude coordinate")
    score: float = Field(..., ge=0.0, le=100.0, description="Threat score (0-100)")
    factors: str = Field(..., description="JSON string of factors used in calculation")
    confidence_level: float = Field(1.0, ge=0.0, le=1.0, description="Confidence in the score (0-1)")

class ThreatScoreCreate(ThreatScoreBase):
    """Model for creating a new threat score."""
    pass

class ThreatScore(ThreatScoreBase):
    """Complete threat score model with ID and timestamps."""
    id: int = Field(..., description="Unique threat score identifier")
    calculated_at: datetime = Field(..., description="When the score was calculated")
    valid_until: datetime = Field(..., description="When the score expires")
    gdacs_events_count: int = Field(0, description="Number of nearby GDACS events")
    
    class Config:
        from_attributes = True

# Response models for complex queries
class SensorWithReadings(Sensor):
    """Sensor model with recent readings."""
    recent_readings: List[Reading] = Field(default_factory=list, description="Recent sensor readings")
    
    class Config:
        from_attributes = True

class IncidentWithAlerts(Incident):
    """Incident model with associated alerts."""
    alerts: List[Alert] = Field(default_factory=list, description="Alerts for this incident")
    
    class Config:
        from_attributes = True

class LocationQuery(BaseModel):
    """Model for location-based queries."""
    latitude: float = Field(..., ge=-90, le=90, description="Center latitude")
    longitude: float = Field(..., ge=-180, le=180, description="Center longitude")
    radius_km: float = Field(10.0, gt=0, le=1000, description="Search radius in kilometers")

class PaginationParams(BaseModel):
    """Model for pagination parameters."""
    skip: int = Field(0, ge=0, description="Number of records to skip")
    limit: int = Field(100, ge=1, le=1000, description="Maximum number of records to return")

# Statistics and analysis models
class GDACSEventStatistics(BaseModel):
    """Model for GDACS event statistics."""
    total_events: int
    by_type: Dict[str, int]
    by_country: Dict[str, int]
    by_threat_level: Dict[str, int]
    recent_events: List[GDACSEvent]

class SensorStatistics(BaseModel):
    """Model for sensor statistics."""
    sensor_id: int
    total_readings: int
    min_value: float
    max_value: float
    avg_value: float
    avg_quality_score: float
    data_completeness: float
    value_range: float
    last_reading: Optional[Reading] = None

class IncidentStatistics(BaseModel):
    """Model for incident statistics."""
    total_incidents: int
    resolved_count: int
    unresolved_count: int
    by_type: Dict[str, Dict[str, int]]
    by_severity: Dict[str, int]

class AlertStatistics(BaseModel):
    """Model for alert statistics."""
    total_alerts: int
    sent_alerts: int
    pending_alerts: int
    by_priority: Dict[str, int]
    by_type: Dict[str, int]
    sent_percentage: float

class ThreatScoreStatistics(BaseModel):
    """Model for threat score statistics."""
    total_scores: int
    average_score: float
    min_score: float
    max_score: float
    score_range: float
    average_confidence: float
    risk_distribution: Dict[str, int]

# Health and status models
class HealthStatus(BaseModel):
    """Model for system health status."""
    status: str = Field(..., description="System status")
    timestamp: str = Field(..., description="Status timestamp")
    service: str = Field(..., description="Service name")
    version: str = Field(..., description="Service version")
    database: str = Field(..., description="Database status")
    uptime: str = Field(..., description="System uptime")

class APIStatus(BaseModel):
    """Model for API status information."""
    api_status: str = Field(..., description="API status")
    version: str = Field(..., description="API version")
    environment: bool = Field(..., description="Debug environment flag")
    database_url: str = Field(..., description="Database connection URL")
    features: Dict[str, str] = Field(..., description="Feature status")
    limits: Dict[str, int] = Field(..., description="System limits")

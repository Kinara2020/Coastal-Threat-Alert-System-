"""
Incidents API routes for the Coastal Threat Alert System.
Handles incident detection, management, and analysis.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
import random

from db import get_db
from models import Incident, IncidentCreate, IncidentUpdate
from database_models import Incident as IncidentDB
from services.anomaly import AnomalyDetectionService

router = APIRouter(prefix="/incidents", tags=["incidents"])

# Initialize anomaly detection service
anomaly_service = AnomalyDetectionService()

# Dummy data for immediate testing
DUMMY_INCIDENTS = [
    {
        "id": 1,
        "title": "High Water Level Detected",
        "description": "Water level sensor at Pier 1 detected levels above normal threshold",
        "incident_type": "flooding",
        "severity_level": "high",
        "latitude": 40.7128,
        "longitude": -74.0060,
        "detected_at": "2024-01-01T10:30:00Z",
        "is_resolved": False,
        "resolved_at": None
    },
    {
        "id": 2,
        "title": "Strong Winds Detected",
        "description": "Wind speed monitor detected sustained winds above 30 m/s",
        "incident_type": "storm_damage",
        "severity_level": "medium",
        "latitude": 40.7028,
        "longitude": -74.0160,
        "detected_at": "2024-01-01T09:15:00Z",
        "is_resolved": True,
        "resolved_at": "2024-01-01T11:00:00Z"
    },
    {
        "id": 3,
        "title": "Large Wave Activity",
        "description": "Offshore buoy detected wave heights exceeding 4 meters",
        "incident_type": "storm_surge",
        "severity_level": "critical",
        "latitude": 40.7228,
        "longitude": -73.9960,
        "detected_at": "2024-01-01T08:45:00Z",
        "is_resolved": False,
        "resolved_at": None
    }
]

@router.get("/", response_model=List[Incident])
async def get_incidents(
    skip: int = 0,
    limit: int = 100,
    incident_type: Optional[str] = Query(None, description="Filter by incident type"),
    severity_level: Optional[str] = Query(None, description="Filter by severity level"),
    is_resolved: Optional[bool] = Query(None, description="Filter by resolution status"),
    start_date: Optional[datetime] = Query(None, description="Filter by start date"),
    end_date: Optional[datetime] = Query(None, description="Filter by end date"),
    db: Session = Depends(get_db)
):
    """
    Get all incidents with optional filtering.
    
    Args:
        skip: Number of records to skip
        limit: Maximum number of records to return
        incident_type: Optional incident type filter
        severity_level: Optional severity level filter
        is_resolved: Optional resolution status filter
        start_date: Optional start date filter
        end_date: Optional end date filter
        db: Database session
        
    Returns:
        List of incidents
    """
    # Filter dummy data based on parameters
    filtered_incidents = DUMMY_INCIDENTS.copy()
    
    if incident_type:
        filtered_incidents = [i for i in filtered_incidents if i["incident_type"] == incident_type]
    
    if severity_level:
        filtered_incidents = [i for i in filtered_incidents if i["severity_level"] == severity_level]
    
    if is_resolved is not None:
        filtered_incidents = [i for i in filtered_incidents if i["is_resolved"] == is_resolved]
    
    if start_date:
        filtered_incidents = [i for i in filtered_incidents if datetime.fromisoformat(i["detected_at"].replace("Z", "+00:00")) >= start_date]
    
    if end_date:
        filtered_incidents = [i for i in filtered_incidents if datetime.fromisoformat(i["detected_at"].replace("Z", "+00:00")) <= end_date]
    
    return filtered_incidents[skip:skip + limit]

@router.get("/{incident_id}", response_model=Incident)
async def get_incident(incident_id: int, db: Session = Depends(get_db)):
    """
    Get a specific incident by ID.
    
    Args:
        incident_id: ID of the incident to retrieve
        db: Database session
        
    Returns:
        Incident data
        
    Raises:
        HTTPException: If incident not found
    """
    incident = next((i for i in DUMMY_INCIDENTS if i["id"] == incident_id), None)
    
    if not incident:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident with ID {incident_id} not found"
        )
    
    return incident

@router.post("/", response_model=Incident, status_code=status.HTTP_201_CREATED)
async def create_incident(incident: IncidentCreate, db: Session = Depends(get_db)):
    """
    Create a new incident.
    
    Args:
        incident: Incident data to create
        db: Database session
        
    Returns:
        Created incident with ID
    """
    # In a real system, this would save to database
    new_incident = {
        "id": max(i["id"] for i in DUMMY_INCIDENTS) + 1,
        **incident.dict(),
        "detected_at": datetime.now().isoformat() + "Z",
        "is_resolved": False,
        "resolved_at": None
    }
    
    DUMMY_INCIDENTS.append(new_incident)
    return new_incident

@router.put("/{incident_id}", response_model=Incident)
async def update_incident(
    incident_id: int,
    incident_update: IncidentUpdate,
    db: Session = Depends(get_db)
):
    """
    Update an existing incident.
    
    Args:
        incident_id: ID of the incident to update
        incident_update: Updated incident data
        db: Database session
        
    Returns:
        Updated incident data
        
    Raises:
        HTTPException: If incident not found
    """
    incident_index = next((i for i, inc in enumerate(DUMMY_INCIDENTS) if inc["id"] == incident_id), None)
    
    if incident_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident with ID {incident_id} not found"
        )
    
    # Update incident with new data
    update_data = incident_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        DUMMY_INCIDENTS[incident_index][key] = value
    
    # If marking as resolved, set resolved_at timestamp
    if incident_update.is_resolved and not DUMMY_INCIDENTS[incident_index]["is_resolved"]:
        DUMMY_INCIDENTS[incident_index]["resolved_at"] = datetime.now().isoformat() + "Z"
    
    return DUMMY_INCIDENTS[incident_index]

@router.delete("/{incident_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_incident(incident_id: int, db: Session = Depends(get_db)):
    """
    Delete an incident.
    
    Args:
        incident_id: ID of the incident to delete
        db: Database session
        
    Raises:
        HTTPException: If incident not found
    """
    incident_index = next((i for i, inc in enumerate(DUMMY_INCIDENTS) if inc["id"] == incident_id), None)
    
    if incident_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident with ID {incident_id} not found"
        )
    
    DUMMY_INCIDENTS.pop(incident_index)

@router.post("/{incident_id}/resolve", response_model=Incident)
async def resolve_incident(incident_id: int, db: Session = Depends(get_db)):
    """
    Mark an incident as resolved.
    
    Args:
        incident_id: ID of the incident to resolve
        db: Database session
        
    Returns:
        Updated incident data
        
    Raises:
        HTTPException: If incident not found or already resolved
    """
    incident_index = next((i for i, inc in enumerate(DUMMY_INCIDENTS) if inc["id"] == incident_id), None)
    
    if incident_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Incident with ID {incident_id} not found"
        )
    
    if DUMMY_INCIDENTS[incident_index]["is_resolved"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Incident with ID {incident_id} is already resolved"
        )
    
    DUMMY_INCIDENTS[incident_index]["is_resolved"] = True
    DUMMY_INCIDENTS[incident_index]["resolved_at"] = datetime.now().isoformat() + "Z"
    
    return DUMMY_INCIDENTS[incident_index]

@router.get("/types/statistics")
async def get_incident_type_statistics(
    days: int = Query(30, description="Number of days for statistics"),
    db: Session = Depends(get_db)
):
    """
    Get statistics by incident type.
    
    Args:
        days: Number of days for statistics
        db: Database session
        
    Returns:
        Statistics grouped by incident type
    """
    # Calculate time threshold
    threshold_time = datetime.now() - timedelta(days=days)
    
    # Filter incidents within time range
    recent_incidents = [
        i for i in DUMMY_INCIDENTS 
        if datetime.fromisoformat(i["detected_at"].replace("Z", "+00:00")) >= threshold_time
    ]
    
    # Group by incident type
    type_stats = {}
    for incident in recent_incidents:
        incident_type = incident["incident_type"]
        if incident_type not in type_stats:
            type_stats[incident_type] = {
                "total_count": 0,
                "resolved_count": 0,
                "unresolved_count": 0,
                "severity_breakdown": {"low": 0, "medium": 0, "high": 0, "critical": 0}
            }
        
        type_stats[incident_type]["total_count"] += 1
        
        if incident["is_resolved"]:
            type_stats[incident_type]["resolved_count"] += 1
        else:
            type_stats[incident_type]["unresolved_count"] += 1
        
        severity = incident["severity_level"]
        if severity in type_stats[incident_type]["severity_breakdown"]:
            type_stats[incident_type]["severity_breakdown"][severity] += 1
    
    return {
        "period_days": days,
        "total_incidents": len(recent_incidents),
        "by_type": type_stats
    }

@router.get("/location/nearby")
async def get_incidents_nearby(
    latitude: float,
    longitude: float,
    radius_km: float = 10.0,
    db: Session = Depends(get_db)
):
    """
    Get incidents within a specified radius of given coordinates.
    
    Args:
        latitude: Latitude coordinate
        longitude: Longitude coordinate
        radius_km: Search radius in kilometers
        db: Database session
        
    Returns:
        List of incidents within the specified radius
    """
    # Simple distance calculation (dummy logic)
    nearby_incidents = []
    
    for incident in DUMMY_INCIDENTS:
        # Calculate simple distance (not accurate, just for demo)
        lat_diff = abs(incident["latitude"] - latitude)
        lon_diff = abs(incident["longitude"] - longitude)
        distance = (lat_diff + lon_diff) * 111  # Rough conversion to km
        
        if distance <= radius_km:
            nearby_incidents.append({
                **incident,
                "distance_km": round(distance, 2)
            })
    
    return {
        "center_latitude": latitude,
        "center_longitude": longitude,
        "radius_km": radius_km,
        "incidents_found": len(nearby_incidents),
        "incidents": nearby_incidents
    }

@router.post("/detect-from-readings")
async def detect_incidents_from_readings(
    sensor_ids: List[int],
    db: Session = Depends(get_db)
):
    """
    Detect incidents from sensor readings using anomaly detection.
    
    Args:
        sensor_ids: List of sensor IDs to analyze
        db: Database session
        
    Returns:
        Detection results and any new incidents created
    """
    # This would normally analyze actual sensor readings
    # For now, return dummy detection results
    
    detection_results = {
        "sensors_analyzed": sensor_ids,
        "anomalies_detected": random.randint(0, 3),
        "new_incidents_created": random.randint(0, 2),
        "analysis_timestamp": datetime.now().isoformat(),
        "message": "Anomaly detection completed (dummy results)"
    }
    
    return detection_results

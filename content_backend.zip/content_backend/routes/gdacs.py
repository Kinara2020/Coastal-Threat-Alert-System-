"""
GDACS disaster events API routes for the Coastal Threat Alert System.
These routes handle real-time disaster data from GDACS.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import math
from db import get_db
from models import GDACSEvent, GDACSEventStatistics
from services.data_loader import GDACSDataLoader

router = APIRouter(prefix="/gdacs", tags=["gdacs-disasters"])

@router.get("/", response_model=List[GDACSEvent])
async def get_gdacs_events(
    skip: int = 0, 
    limit: int = 100,
    event_type: Optional[str] = Query(None, description="Filter by event type"),
    country: Optional[str] = Query(None, description="Filter by country"),
    threat_level: Optional[str] = Query(None, description="Filter by threat level"),
    severity_min: Optional[float] = Query(None, description="Minimum severity value"),
    severity_max: Optional[float] = Query(None, description="Maximum severity value"),
    from_date: Optional[datetime] = Query(None, description="Filter events from this date"),
    to_date: Optional[datetime] = Query(None, description="Filter events until this date"),
    db: Session = Depends(get_db)
):
    """Get GDACS disaster events with filtering options."""
    query = db.query(GDACSEvent)
    
    # Apply filters
    if event_type:
        query = query.filter(GDACSEvent.event_type == event_type)
    if country:
        query = query.filter(GDACSEvent.country == country)
    if threat_level:
        query = query.filter(GDACSEvent.threat_level == threat_level)
    if severity_min is not None:
        query = query.filter(GDACSEvent.severity_value >= severity_min)
    if severity_max is not None:
        query = query.filter(GDACSEvent.severity_value <= severity_max)
    if from_date:
        query = query.filter(GDACSEvent.from_date >= from_date)
    if to_date:
        query = query.filter(GDACSEvent.to_date <= to_date)
    
    # Order by most recent first
    query = query.order_by(GDACSEvent.from_date.desc())
    
    # Apply pagination
    total = query.count()
    events = query.offset(skip).limit(limit).all()
    
    return events

@router.get("/{event_id}", response_model=GDACSEvent)
async def get_gdacs_event(event_id: str, db: Session = Depends(get_db)):
    """Get a specific GDACS event by ID."""
    event = db.query(GDACSEvent).filter(GDACSEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="GDACS event not found")
    return event

@router.get("/types/{event_type}", response_model=List[GDACSEvent])
async def get_gdacs_events_by_type(
    event_type: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get GDACS events by specific type (Earthquake, Wildfire, etc.)."""
    events = db.query(GDACSEvent).filter(
        GDACSEvent.event_type == event_type
    ).order_by(GDACSEvent.from_date.desc()).offset(skip).limit(limit).all()
    
    return events

@router.get("/country/{country_code}", response_model=List[GDACSEvent])
async def get_gdacs_events_by_country(
    country_code: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get GDACS events by country code or name."""
    events = db.query(GDACSEvent).filter(
        (GDACSEvent.iso3 == country_code) | (GDACSEvent.country == country_code)
    ).order_by(GDACSEvent.from_date.desc()).offset(skip).limit(limit).all()
    
    return events

@router.get("/location/nearby")
async def get_gdacs_events_nearby(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
    radius_km: float = Query(100.0, gt=0, le=1000),
    limit: int = Query(50, le=200),
    db: Session = Depends(get_db)
):
    """Get GDACS events within a specified radius of coordinates."""
    events = db.query(GDACSEvent).all()
    
    nearby_events = []
    for event in events:
        # Calculate distance using Haversine formula
        distance = calculate_distance(
            latitude, longitude, 
            event.geo_lat, event.geo_long
        )
        
        if distance <= radius_km:
            nearby_events.append({
                "event": event,
                "distance_km": round(distance, 2)
            })
    
    # Sort by distance and limit results
    nearby_events.sort(key=lambda x: x["distance_km"])
    return nearby_events[:limit]

@router.get("/statistics", response_model=GDACSEventStatistics)
async def get_gdacs_statistics(db: Session = Depends(get_db)):
    """Get comprehensive statistics about GDACS events."""
    loader = GDACSDataLoader(db)
    return loader.get_gdacs_statistics()

@router.get("/recent", response_model=List[GDACSEvent])
async def get_recent_gdacs_events(
    days: int = Query(7, ge=1, le=30),
    limit: int = Query(20, le=100),
    db: Session = Depends(get_db)
):
    """Get recent GDACS events from the last N days."""
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    events = db.query(GDACSEvent).filter(
        GDACSEvent.from_date >= cutoff_date
    ).order_by(GDACSEvent.from_date.desc()).limit(limit).all()
    
    return events

@router.get("/threat-level/{threat_level}", response_model=List[GDACSEvent])
async def get_gdacs_events_by_threat_level(
    threat_level: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Get GDACS events by threat level (Green, Orange, Red)."""
    events = db.query(GDACSEvent).filter(
        GDACSEvent.threat_level == threat_level
    ).order_by(GDACSEvent.from_date.desc()).offset(skip).limit(limit).all()
    
    return events

@router.get("/search")
async def search_gdacs_events(
    q: str = Query(..., min_length=2, description="Search query"),
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Search GDACS events by title, summary, or country."""
    query = db.query(GDACSEvent).filter(
        (GDACSEvent.title.contains(q)) |
        (GDACSEvent.summary.contains(q)) |
        (GDACSEvent.country.contains(q))
    )
    
    total = query.count()
    events = query.order_by(GDACSEvent.from_date.desc()).offset(skip).limit(limit).all()
    
    return {
        "query": q,
        "total_results": total,
        "events": events,
        "pagination": {
            "skip": skip,
            "limit": limit,
            "has_more": skip + limit < total
        }
    }

@router.post("/load-data")
async def load_gdacs_data(
    csv_file_path: str = "ctas.csv",
    db: Session = Depends(get_db)
):
    """Load GDACS data from CSV file into database."""
    try:
        loader = GDACSDataLoader(db)
        result = loader.load_gdacs_csv(csv_file_path)
        
        if result["success"]:
            return {
                "message": "GDACS data loaded successfully",
                "statistics": result
            }
        else:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to load GDACS data: {result['errors']}"
            )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error loading GDACS data: {str(e)}"
        )

@router.delete("/clear-data")
async def clear_gdacs_data(db: Session = Depends(get_db)):
    """Clear all GDACS data from database."""
    try:
        loader = GDACSDataLoader(db)
        success = loader.clear_gdacs_data()
        
        if success:
            return {"message": "All GDACS data cleared successfully"}
        else:
            raise HTTPException(
                status_code=500,
                detail="Failed to clear GDACS data"
            )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error clearing GDACS data: {str(e)}"
        )

def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance between two coordinates using Haversine formula."""
    R = 6371  # Earth's radius in kilometers
    
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)
    
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    
    a = math.sin(dlat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    
    return R * c

"""
Sensor readings API routes for the Coastal Threat Alert System.
Handles CRUD operations for sensor data readings.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
import random

from db import get_db
from models import Reading, ReadingCreate
from database_models import Reading as ReadingDB

router = APIRouter(prefix="/readings", tags=["readings"])

# Dummy data for immediate testing
DUMMY_READINGS = [
    {
        "id": 1,
        "sensor_id": 1,
        "timestamp": "2024-01-01T10:00:00Z",
        "value": 2.5,
        "unit": "meters",
        "quality_score": 0.95
    },
    {
        "id": 2,
        "sensor_id": 1,
        "timestamp": "2024-01-01T11:00:00Z",
        "value": 2.7,
        "unit": "meters",
        "quality_score": 0.92
    },
    {
        "id": 3,
        "sensor_id": 2,
        "timestamp": "2024-01-01T10:00:00Z",
        "value": 15.2,
        "unit": "m/s",
        "quality_score": 0.88
    },
    {
        "id": 4,
        "sensor_id": 3,
        "timestamp": "2024-01-01T10:00:00Z",
        "value": 1.8,
        "unit": "meters",
        "quality_score": 0.91
    }
]

@router.get("/", response_model=List[Reading])
async def get_readings(
    skip: int = 0,
    limit: int = 100,
    sensor_id: Optional[int] = Query(None, description="Filter by sensor ID"),
    start_time: Optional[datetime] = Query(None, description="Start time for filtering"),
    end_time: Optional[datetime] = Query(None, description="End time for filtering"),
    db: Session = Depends(get_db)
):
    """
    Get all sensor readings with optional filtering.
    
    Args:
        skip: Number of records to skip
        limit: Maximum number of records to return
        sensor_id: Optional sensor ID filter
        start_time: Optional start time filter
        end_time: Optional end time filter
        db: Database session
        
    Returns:
        List of sensor readings
    """
    # Filter dummy data based on parameters
    filtered_readings = DUMMY_READINGS.copy()
    
    if sensor_id:
        filtered_readings = [r for r in filtered_readings if r["sensor_id"] == sensor_id]
    
    if start_time:
        filtered_readings = [r for r in filtered_readings if datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00")) >= start_time]
    
    if end_time:
        filtered_readings = [r for r in filtered_readings if datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00")) <= end_time]
    
    return filtered_readings[skip:skip + limit]

@router.get("/{reading_id}", response_model=Reading)
async def get_reading(reading_id: int, db: Session = Depends(get_db)):
    """
    Get a specific reading by ID.
    
    Args:
        reading_id: ID of the reading to retrieve
        db: Database session
        
    Returns:
        Reading data
        
    Raises:
        HTTPException: If reading not found
    """
    reading = next((r for r in DUMMY_READINGS if r["id"] == reading_id), None)
    
    if not reading:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Reading with ID {reading_id} not found"
        )
    
    return reading

@router.post("/", response_model=Reading, status_code=status.HTTP_201_CREATED)
async def create_reading(reading: ReadingCreate, db: Session = Depends(get_db)):
    """
    Create a new sensor reading.
    
    Args:
        reading: Reading data to create
        db: Database session
        
    Returns:
        Created reading with ID
    """
    # In a real system, this would save to database
    new_reading = {
        "id": max(r["id"] for r in DUMMY_READINGS) + 1,
        **reading.dict(),
        "timestamp": datetime.now().isoformat() + "Z"
    }
    
    DUMMY_READINGS.append(new_reading)
    return new_reading

@router.get("/sensor/{sensor_id}/latest", response_model=Reading)
async def get_latest_reading(sensor_id: int, db: Session = Depends(get_db)):
    """
    Get the latest reading from a specific sensor.
    
    Args:
        sensor_id: ID of the sensor
        db: Database session
        
    Returns:
        Latest reading from the sensor
        
    Raises:
        HTTPException: If no readings found for sensor
    """
    sensor_readings = [r for r in DUMMY_READINGS if r["sensor_id"] == sensor_id]
    
    if not sensor_readings:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No readings found for sensor {sensor_id}"
        )
    
    # Sort by timestamp and get latest
    latest_reading = max(sensor_readings, key=lambda x: x["timestamp"])
    return latest_reading

@router.get("/sensor/{sensor_id}/history")
async def get_sensor_history(
    sensor_id: int,
    hours: int = Query(24, description="Number of hours of history to retrieve"),
    db: Session = Depends(get_db)
):
    """
    Get historical readings from a specific sensor.
    
    Args:
        sensor_id: ID of the sensor
        hours: Number of hours of history to retrieve
        db: Database session
        
    Returns:
        Historical readings with statistics
    """
    sensor_readings = [r for r in DUMMY_READINGS if r["sensor_id"] == sensor_id]
    
    if not sensor_readings:
        return {
            "sensor_id": sensor_id,
            "hours": hours,
            "readings_count": 0,
            "readings": [],
            "statistics": {}
        }
    
    # Calculate time threshold
    threshold_time = datetime.now() - timedelta(hours=hours)
    
    # Filter readings within time range
    recent_readings = [
        r for r in sensor_readings 
        if datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00")) >= threshold_time
    ]
    
    # Calculate statistics
    if recent_readings:
        values = [r["value"] for r in recent_readings]
        stats = {
            "min_value": min(values),
            "max_value": max(values),
            "avg_value": sum(values) / len(values),
            "total_readings": len(recent_readings)
        }
    else:
        stats = {}
    
    return {
        "sensor_id": sensor_id,
        "hours": hours,
        "readings_count": len(recent_readings),
        "readings": recent_readings,
        "statistics": stats
    }

@router.get("/sensor/{sensor_id}/statistics")
async def get_sensor_statistics(
    sensor_id: int,
    days: int = Query(7, description="Number of days for statistics"),
    db: Session = Depends(get_db)
):
    """
    Get statistical summary for a specific sensor.
    
    Args:
        sensor_id: ID of the sensor
        days: Number of days for statistics
        db: Database session
        
    Returns:
        Statistical summary for the sensor
    """
    sensor_readings = [r for r in DUMMY_READINGS if r["sensor_id"] == sensor_id]
    
    if not sensor_readings:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No readings found for sensor {sensor_id}"
        )
    
    # Calculate time threshold
    threshold_time = datetime.now() - timedelta(days=days)
    
    # Filter readings within time range
    recent_readings = [
        r for r in sensor_readings 
        if datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00")) >= threshold_time
    ]
    
    if not recent_readings:
        return {
            "sensor_id": sensor_id,
            "days": days,
            "message": "No readings found in specified time range",
            "statistics": {}
        }
    
    # Calculate comprehensive statistics
    values = [r["value"] for r in recent_readings]
    quality_scores = [r["quality_score"] for r in recent_readings]
    
    stats = {
        "total_readings": len(recent_readings),
        "min_value": min(values),
        "max_value": max(values),
        "avg_value": round(sum(values) / len(values), 3),
        "avg_quality_score": round(sum(quality_scores) / len(quality_scores), 3),
        "data_completeness": len(recent_readings) / (days * 24) * 100,  # Assuming hourly readings
        "value_range": max(values) - min(values),
        "last_reading": max(recent_readings, key=lambda x: x["timestamp"])
    }
    
    return {
        "sensor_id": sensor_id,
        "days": days,
        "statistics": stats
    }

@router.delete("/{reading_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_reading(reading_id: int, db: Session = Depends(get_db)):
    """
    Delete a sensor reading.
    
    Args:
        reading_id: ID of the reading to delete
        db: Database session
        
    Raises:
        HTTPException: If reading not found
    """
    reading_index = next((i for i, r in enumerate(DUMMY_READINGS) if r["id"] == reading_id), None)
    
    if reading_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Reading with ID {reading_id} not found"
        )
    
    DUMMY_READINGS.pop(reading_index)

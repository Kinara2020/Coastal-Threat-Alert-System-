"""
Sensors API routes for the Coastal Threat Alert System.
Handles CRUD operations for environmental sensors.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
import random

from db import get_db
from models import Sensor, SensorCreate, SensorUpdate
from database_models import Sensor as SensorDB

router = APIRouter(prefix="/sensors", tags=["sensors"])

# Dummy data for immediate testing
DUMMY_SENSORS = [
    {
        "id": 1,
        "name": "Water Level Sensor - Pier 1",
        "location": "Pier 1, Downtown Harbor",
        "sensor_type": "water_level",
        "latitude": 40.7128,
        "longitude": -74.0060,
        "is_active": True
    },
    {
        "id": 2,
        "name": "Wind Speed Monitor - Beach Station",
        "location": "Main Beach Station",
        "sensor_type": "wind_speed",
        "latitude": 40.7028,
        "longitude": -74.0160,
        "is_active": True
    },
    {
        "id": 3,
        "name": "Wave Height Sensor - Offshore Buoy",
        "location": "Offshore Buoy A",
        "sensor_type": "wave_height",
        "latitude": 40.7228,
        "longitude": -73.9960,
        "is_active": True
    }
]

@router.get("/", response_model=List[Sensor])
async def get_sensors(
    skip: int = 0, 
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    Get all sensors with pagination support.
    
    Args:
        skip: Number of records to skip
        limit: Maximum number of records to return
        db: Database session
        
    Returns:
        List of sensors
    """
    # For now, return dummy data
    # In a real system, this would query the database
    return DUMMY_SENSORS[skip:skip + limit]

@router.get("/{sensor_id}", response_model=Sensor)
async def get_sensor(sensor_id: int, db: Session = Depends(get_db)):
    """
    Get a specific sensor by ID.
    
    Args:
        sensor_id: ID of the sensor to retrieve
        db: Database session
        
    Returns:
        Sensor data
        
    Raises:
        HTTPException: If sensor not found
    """
    # Find sensor in dummy data
    sensor = next((s for s in DUMMY_SENSORS if s["id"] == sensor_id), None)
    
    if not sensor:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Sensor with ID {sensor_id} not found"
        )
    
    return sensor

@router.post("/", response_model=Sensor, status_code=status.HTTP_201_CREATED)
async def create_sensor(sensor: SensorCreate, db: Session = Depends(get_db)):
    """
    Create a new sensor.
    
    Args:
        sensor: Sensor data to create
        db: Database session
        
    Returns:
        Created sensor with ID
    """
    # In a real system, this would save to database
    # For now, generate a dummy ID and return the sensor
    new_sensor = {
        "id": max(s["id"] for s in DUMMY_SENSORS) + 1,
        **sensor.dict(),
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": None
    }
    
    DUMMY_SENSORS.append(new_sensor)
    return new_sensor

@router.put("/{sensor_id}", response_model=Sensor)
async def update_sensor(
    sensor_id: int, 
    sensor_update: SensorUpdate, 
    db: Session = Depends(get_db)
):
    """
    Update an existing sensor.
    
    Args:
        sensor_id: ID of the sensor to update
        sensor_update: Updated sensor data
        db: Database session
        
    Returns:
        Updated sensor data
        
    Raises:
        HTTPException: If sensor not found
    """
    # Find sensor in dummy data
    sensor_index = next((i for i, s in enumerate(DUMMY_SENSORS) if s["id"] == sensor_id), None)
    
    if sensor_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Sensor with ID {sensor_id} not found"
        )
    
    # Update sensor with new data
    update_data = sensor_update.dict(exclude_unset=True)
    for key, value in update_data.items():
        DUMMY_SENSORS[sensor_index][key] = value
    
    DUMMY_SENSORS[sensor_index]["updated_at"] = "2024-01-01T00:00:00Z"
    
    return DUMMY_SENSORS[sensor_index]

@router.delete("/{sensor_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_sensor(sensor_id: int, db: Session = Depends(get_db)):
    """
    Delete a sensor.
    
    Args:
        sensor_id: ID of the sensor to delete
        db: Database session
        
    Raises:
        HTTPException: If sensor not found
    """
    # Find sensor in dummy data
    sensor_index = next((i for i, s in enumerate(DUMMY_SENSORS) if s["id"] == sensor_id), None)
    
    if sensor_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Sensor with ID {sensor_id} not found"
        )
    
    # Remove sensor from dummy data
    DUMMY_SENSORS.pop(sensor_index)

@router.get("/types/{sensor_type}", response_model=List[Sensor])
async def get_sensors_by_type(
    sensor_type: str, 
    db: Session = Depends(get_db)
):
    """
    Get all sensors of a specific type.
    
    Args:
        sensor_type: Type of sensor to filter by
        db: Database session
        
    Returns:
        List of sensors of the specified type
    """
    # Filter dummy data by sensor type
    filtered_sensors = [s for s in DUMMY_SENSORS if s["sensor_type"] == sensor_type]
    return filtered_sensors

@router.get("/location/nearby")
async def get_sensors_nearby(
    latitude: float,
    longitude: float,
    radius_km: float = 10.0,
    db: Session = Depends(get_db)
):
    """
    Get sensors within a specified radius of given coordinates.
    
    Args:
        latitude: Latitude coordinate
        longitude: Longitude coordinate
        radius_km: Search radius in kilometers
        db: Database session
        
    Returns:
        List of sensors within the specified radius
    """
    # Simple distance calculation (dummy logic)
    # In a real system, this would use proper geospatial queries
    nearby_sensors = []
    
    for sensor in DUMMY_SENSORS:
        # Calculate simple distance (not accurate, just for demo)
        lat_diff = abs(sensor["latitude"] - latitude)
        lon_diff = abs(sensor["longitude"] - longitude)
        distance = (lat_diff + lon_diff) * 111  # Rough conversion to km
        
        if distance <= radius_km:
            nearby_sensors.append({
                **sensor,
                "distance_km": round(distance, 2)
            })
    
    return {
        "center_latitude": latitude,
        "center_longitude": longitude,
        "radius_km": radius_km,
        "sensors_found": len(nearby_sensors),
        "sensors": nearby_sensors
    }

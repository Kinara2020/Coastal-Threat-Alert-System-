"""
Alerts API routes for the Coastal Threat Alert System.
Handles alert creation, management, and notification delivery.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
import random

from db import get_db
from models import Alert, AlertCreate
from database_models import Alert as AlertDB

router = APIRouter(prefix="/alerts", tags=["alerts"])

# Dummy data for immediate testing
DUMMY_ALERTS = [
    {
        "id": 1,
        "incident_id": 1,
        "alert_type": "email",
        "message": "URGENT: High water levels detected at Pier 1. Immediate action required.",
        "priority": "high",
        "sent_at": "2024-01-01T10:35:00Z",
        "is_sent": True,
        "recipient": "emergency@coastal.gov"
    },
    {
        "id": 2,
        "incident_id": 1,
        "alert_type": "sms",
        "message": "ALERT: Water level critical at Pier 1. Evacuate area immediately.",
        "priority": "urgent",
        "sent_at": "2024-01-01T10:36:00Z",
        "is_sent": True,
        "recipient": "+1234567890"
    },
    {
        "id": 3,
        "incident_id": 2,
        "alert_type": "push_notification",
        "message": "Wind speeds above normal at Beach Station. Monitor conditions.",
        "priority": "medium",
        "sent_at": "2024-01-01T09:20:00Z",
        "is_sent": True,
        "recipient": "mobile_app_users"
    },
    {
        "id": 4,
        "incident_id": 3,
        "alert_type": "email",
        "message": "CRITICAL: Large wave activity detected offshore. Avoid coastal areas.",
        "priority": "urgent",
        "sent_at": "2024-01-01T08:50:00Z",
        "is_sent": True,
        "recipient": "coastguard@emergency.gov"
    }
]

@router.get("/", response_model=List[Alert])
async def get_alerts(
    skip: int = 0,
    limit: int = 100,
    incident_id: Optional[int] = Query(None, description="Filter by incident ID"),
    alert_type: Optional[str] = Query(None, description="Filter by alert type"),
    priority: Optional[str] = Query(None, description="Filter by priority level"),
    is_sent: Optional[bool] = Query(None, description="Filter by sent status"),
    db: Session = Depends(get_db)
):
    """
    Get all alerts with optional filtering.
    
    Args:
        skip: Number of records to skip
        limit: Maximum number of records to return
        incident_id: Optional incident ID filter
        alert_type: Optional alert type filter
        priority: Optional priority level filter
        is_sent: Optional sent status filter
        db: Database session
        
    Returns:
        List of alerts
    """
    # Filter dummy data based on parameters
    filtered_alerts = DUMMY_ALERTS.copy()
    
    if incident_id:
        filtered_alerts = [a for a in filtered_alerts if a["incident_id"] == incident_id]
    
    if alert_type:
        filtered_alerts = [a for a in filtered_alerts if a["alert_type"] == alert_type]
    
    if priority:
        filtered_alerts = [a for a in filtered_alerts if a["priority"] == priority]
    
    if is_sent is not None:
        filtered_alerts = [a for a in filtered_alerts if a["is_sent"] == is_sent]
    
    return filtered_alerts[skip:skip + limit]

@router.get("/{alert_id}", response_model=Alert)
async def get_alert(alert_id: int, db: Session = Depends(get_db)):
    """
    Get a specific alert by ID.
    
    Args:
        alert_id: ID of the alert to retrieve
        db: Database session
        
    Returns:
        Alert data
        
    Raises:
        HTTPException: If alert not found
    """
    alert = next((a for a in DUMMY_ALERTS if a["id"] == alert_id), None)
    
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Alert with ID {alert_id} not found"
        )
    
    return alert

@router.post("/", response_model=Alert, status_code=status.HTTP_201_CREATED)
async def create_alert(alert: AlertCreate, db: Session = Depends(get_db)):
    """
    Create a new alert.
    
    Args:
        alert: Alert data to create
        db: Database session
        
    Returns:
        Created alert with ID
    """
    # In a real system, this would save to database
    new_alert = {
        "id": max(a["id"] for a in DUMMY_ALERTS) + 1,
        **alert.dict(),
        "sent_at": datetime.now().isoformat() + "Z",
        "is_sent": False
    }
    
    DUMMY_ALERTS.append(new_alert)
    return new_alert

@router.post("/{alert_id}/send", response_model=Alert)
async def send_alert(alert_id: int, db: Session = Depends(get_db)):
    """
    Mark an alert as sent and update sent timestamp.
    
    Args:
        alert_id: ID of the alert to send
        db: Database session
        
    Returns:
        Updated alert data
        
    Raises:
        HTTPException: If alert not found or already sent
    """
    alert_index = next((i for i, a in enumerate(DUMMY_ALERTS) if a["id"] == alert_id), None)
    
    if alert_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Alert with ID {alert_id} not found"
        )
    
    if DUMMY_ALERTS[alert_index]["is_sent"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Alert with ID {alert_id} has already been sent"
        )
    
    DUMMY_ALERTS[alert_index]["is_sent"] = True
    DUMMY_ALERTS[alert_index]["sent_at"] = datetime.now().isoformat() + "Z"
    
    return DUMMY_ALERTS[alert_index]

@router.delete("/{alert_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_alert(alert_id: int, db: Session = Depends(get_db)):
    """
    Delete an alert.
    
    Args:
        alert_id: ID of the alert to delete
        db: Database session
        
    Raises:
        HTTPException: If alert not found
    """
    alert_index = next((i for i, a in enumerate(DUMMY_ALERTS) if a["id"] == alert_id), None)
    
    if alert_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Alert with ID {alert_id} not found"
        )
    
    DUMMY_ALERTS.pop(alert_index)

@router.get("/incident/{incident_id}", response_model=List[Alert])
async def get_alerts_by_incident(incident_id: int, db: Session = Depends(get_db)):
    """
    Get all alerts for a specific incident.
    
    Args:
        incident_id: ID of the incident
        db: Database session
        
    Returns:
        List of alerts for the incident
    """
    incident_alerts = [a for a in DUMMY_ALERTS if a["incident_id"] == incident_id]
    return incident_alerts

@router.get("/priority/{priority_level}", response_model=List[Alert])
async def get_alerts_by_priority(priority_level: str, db: Session = Depends(get_db)):
    """
    Get all alerts of a specific priority level.
    
    Args:
        priority_level: Priority level to filter by
        db: Database session
        
    Returns:
        List of alerts with the specified priority
    """
    priority_alerts = [a for a in DUMMY_ALERTS if a["priority"] == priority_level]
    return priority_alerts

@router.get("/type/{alert_type}", response_model=List[Alert])
async def get_alerts_by_type(alert_type: str, db: Session = Depends(get_db)):
    """
    Get all alerts of a specific type.
    
    Args:
        alert_type: Type of alert to filter by
        db: Database session
        
    Returns:
        List of alerts of the specified type
    """
    type_alerts = [a for a in DUMMY_ALERTS if a["alert_type"] == alert_type]
    return type_alerts

@router.get("/statistics/summary")
async def get_alert_statistics(
    days: int = Query(7, description="Number of days for statistics"),
    db: Session = Depends(get_db)
):
    """
    Get alert statistics summary.
    
    Args:
        days: Number of days for statistics
        db: Database session
        
    Returns:
        Alert statistics summary
    """
    # Calculate time threshold
    threshold_time = datetime.now() - timedelta(days=days)
    
    # Filter alerts within time range
    recent_alerts = [
        a for a in DUMMY_ALERTS 
        if datetime.fromisoformat(a["sent_at"].replace("Z", "+00:00")) >= threshold_time
    ]
    
    # Calculate statistics
    total_alerts = len(recent_alerts)
    sent_alerts = len([a for a in recent_alerts if a["is_sent"]])
    pending_alerts = total_alerts - sent_alerts
    
    # Priority breakdown
    priority_stats = {}
    for alert in recent_alerts:
        priority = alert["priority"]
        if priority not in priority_stats:
            priority_stats[priority] = 0
        priority_stats[priority] += 1
    
    # Type breakdown
    type_stats = {}
    for alert in recent_alerts:
        alert_type = alert["alert_type"]
        if alert_type not in type_stats:
            type_stats[alert_type] = 0
        type_stats[alert_type] += 1
    
    return {
        "period_days": days,
        "total_alerts": total_alerts,
        "sent_alerts": sent_alerts,
        "pending_alerts": pending_alerts,
        "by_priority": priority_stats,
        "by_type": type_stats,
        "sent_percentage": round((sent_alerts / total_alerts * 100) if total_alerts > 0 else 0, 2)
    }

@router.post("/bulk/create")
async def create_bulk_alerts(
    incident_id: int,
    alert_types: List[str],
    message_template: str,
    priority: str = "medium",
    db: Session = Depends(get_db)
):
    """
    Create multiple alerts for different notification channels.
    
    Args:
        incident_id: ID of the incident to create alerts for
        alert_types: List of alert types to create
        message_template: Template message for the alerts
        priority: Priority level for all alerts
        db: Database session
        
    Returns:
        Summary of created alerts
    """
    created_alerts = []
    
    for alert_type in alert_types:
        # Generate unique message for each alert type
        if alert_type == "email":
            message = f"EMAIL: {message_template}"
            recipient = "admin@coastal.gov"
        elif alert_type == "sms":
            message = f"SMS: {message_template}"
            recipient = "+1234567890"
        elif alert_type == "push_notification":
            message = f"PUSH: {message_template}"
            recipient = "mobile_users"
        else:
            message = message_template
            recipient = "default@coastal.gov"
        
        new_alert = {
            "id": max(a["id"] for a in DUMMY_ALERTS) + 1,
            "incident_id": incident_id,
            "alert_type": alert_type,
            "message": message,
            "priority": priority,
            "sent_at": datetime.now().isoformat() + "Z",
            "is_sent": False,
            "recipient": recipient
        }
        
        DUMMY_ALERTS.append(new_alert)
        created_alerts.append(new_alert)
    
    return {
        "incident_id": incident_id,
        "alerts_created": len(created_alerts),
        "alert_types": alert_types,
        "created_alerts": created_alerts
    }

"""
Threat Score API routes for the Coastal Threat Alert System.
Handles risk assessment, threat scoring, and risk analysis.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import random
import json

from db import get_db
from models import ThreatScore, ThreatScoreCreate
from database_models import ThreatScore as ThreatScoreDB

router = APIRouter(prefix="/score", tags=["threat-scoring"])

# Dummy data for immediate testing
DUMMY_THREAT_SCORES = [
    {
        "id": 1,
        "location_name": "Downtown Harbor",
        "latitude": 40.7128,
        "longitude": -74.0060,
        "score": 75.5,
        "factors": json.dumps({
            "water_level": 0.8,
            "wind_speed": 0.6,
            "wave_height": 0.9,
            "historical_incidents": 0.7
        }),
        "calculated_at": "2024-01-01T10:00:00Z",
        "valid_until": "2024-01-02T10:00:00Z",
        "confidence_level": 0.85
    },
    {
        "id": 2,
        "location_name": "Main Beach Station",
        "latitude": 40.7028,
        "longitude": -74.0160,
        "score": 45.2,
        "factors": json.dumps({
            "water_level": 0.3,
            "wind_speed": 0.8,
            "wave_height": 0.4,
            "historical_incidents": 0.5
        }),
        "calculated_at": "2024-01-01T10:00:00Z",
        "valid_until": "2024-01-02T10:00:00Z",
        "confidence_level": 0.78
    },
    {
        "id": 3,
        "location_name": "Offshore Buoy A",
        "latitude": 40.7228,
        "longitude": -73.9960,
        "score": 92.1,
        "factors": json.dumps({
            "water_level": 0.9,
            "wind_speed": 0.7,
            "wave_height": 0.95,
            "historical_incidents": 0.8
        }),
        "calculated_at": "2024-01-01T10:00:00Z",
        "valid_until": "2024-01-02T10:00:00Z",
        "confidence_level": 0.91
    }
]

@router.get("/", response_model=List[ThreatScore])
async def get_threat_scores(
    skip: int = 0,
    limit: int = 100,
    min_score: Optional[float] = Query(None, description="Minimum threat score"),
    max_score: Optional[float] = Query(None, description="Maximum threat score"),
    location_name: Optional[str] = Query(None, description="Filter by location name"),
    db: Session = Depends(get_db)
):
    """
    Get all threat scores with optional filtering.
    
    Args:
        skip: Number of records to skip
        limit: Maximum number of records to return
        min_score: Optional minimum score filter
        max_score: Optional maximum score filter
        location_name: Optional location name filter
        db: Database session
        
    Returns:
        List of threat scores
    """
    # Filter dummy data based on parameters
    filtered_scores = DUMMY_THREAT_SCORES.copy()
    
    if min_score is not None:
        filtered_scores = [s for s in filtered_scores if s["score"] >= min_score]
    
    if max_score is not None:
        filtered_scores = [s for s in filtered_scores if s["score"] <= max_score]
    
    if location_name:
        filtered_scores = [s for s in filtered_scores if location_name.lower() in s["location_name"].lower()]
    
    return filtered_scores[skip:skip + limit]

@router.get("/{score_id}", response_model=ThreatScore)
async def get_threat_score(score_id: int, db: Session = Depends(get_db)):
    """
    Get a specific threat score by ID.
    
    Args:
        score_id: ID of the threat score to retrieve
        db: Database session
        
    Returns:
        Threat score data
        
    Raises:
        HTTPException: If threat score not found
    """
    score = next((s for s in DUMMY_THREAT_SCORES if s["id"] == score_id), None)
    
    if not score:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Threat score with ID {score_id} not found"
        )
    
    return score

@router.post("/", response_model=ThreatScore, status_code=status.HTTP_201_CREATED)
async def create_threat_score(score: ThreatScoreCreate, db: Session = Depends(get_db)):
    """
    Create a new threat score.
    
    Args:
        score: Threat score data to create
        db: Database session
        
    Returns:
        Created threat score with ID
    """
    # In a real system, this would save to database
    new_score = {
        "id": max(s["id"] for s in DUMMY_THREAT_SCORES) + 1,
        **score.dict(),
        "calculated_at": datetime.now().isoformat() + "Z",
        "valid_until": (datetime.now() + timedelta(days=1)).isoformat() + "Z"
    }
    
    DUMMY_THREAT_SCORES.append(new_score)
    return new_score

@router.delete("/{score_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_threat_score(score_id: int, db: Session = Depends(get_db)):
    """
    Delete a threat score.
    
    Args:
        score_id: ID of the threat score to delete
        db: Database session
        
    Raises:
        HTTPException: If threat score not found
    """
    score_index = next((i for i, s in enumerate(DUMMY_THREAT_SCORES) if s["id"] == score_id), None)
    
    if score_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Threat score with ID {score_id} not found"
        )
    
    DUMMY_THREAT_SCORES.pop(score_index)

@router.get("/location/{location_name}", response_model=List[ThreatScore])
async def get_threat_scores_by_location(location_name: str, db: Session = Depends(get_db)):
    """
    Get threat scores for a specific location.
    
    Args:
        location_name: Name of the location to filter by
        db: Database session
        
    Returns:
        List of threat scores for the location
    """
    location_scores = [s for s in DUMMY_THREAT_SCORES if location_name.lower() in s["location_name"].lower()]
    return location_scores

@router.get("/location/nearby")
async def get_threat_scores_nearby(
    latitude: float,
    longitude: float,
    radius_km: float = 10.0,
    db: Session = Depends(get_db)
):
    """
    Get threat scores within a specified radius of given coordinates.
    
    Args:
        latitude: Latitude coordinate
        longitude: Longitude coordinate
        radius_km: Search radius in kilometers
        db: Database session
        
    Returns:
        List of threat scores within the specified radius
    """
    # Simple distance calculation (dummy logic)
    nearby_scores = []
    
    for score in DUMMY_THREAT_SCORES:
        # Calculate simple distance (not accurate, just for demo)
        lat_diff = abs(score["latitude"] - latitude)
        lon_diff = abs(score["longitude"] - longitude)
        distance = (lat_diff + lon_diff) * 111  # Rough conversion to km
        
        if distance <= radius_km:
            nearby_scores.append({
                **score,
                "distance_km": round(distance, 2)
            })
    
    return {
        "center_latitude": latitude,
        "center_longitude": longitude,
        "radius_km": radius_km,
        "scores_found": len(nearby_scores),
        "scores": nearby_scores
    }

@router.post("/calculate")
async def calculate_threat_score(
    latitude: float,
    longitude: float,
    location_name: str,
    db: Session = Depends(get_db)
):
    """
    Calculate a new threat score for a specific location.
    
    Args:
        latitude: Latitude coordinate
        longitude: Longitude coordinate
        location_name: Name of the location
        db: Database session
        
    Returns:
        Calculated threat score with factors
    """
    # Dummy threat score calculation logic
    # In a real system, this would analyze sensor data, historical incidents, etc.
    
    # Generate random factors for demonstration
    water_level_factor = random.uniform(0.1, 1.0)
    wind_speed_factor = random.uniform(0.1, 1.0)
    wave_height_factor = random.uniform(0.1, 1.0)
    historical_incidents_factor = random.uniform(0.1, 1.0)
    
    # Calculate weighted score (0-100)
    score = (
        water_level_factor * 0.3 +
        wind_speed_factor * 0.25 +
        wave_height_factor * 0.3 +
        historical_incidents_factor * 0.15
    ) * 100
    
    # Determine confidence level based on data availability
    confidence_level = random.uniform(0.6, 0.95)
    
    # Create factors dictionary
    factors = {
        "water_level": round(water_level_factor, 3),
        "wind_speed": round(wind_speed_factor, 3),
        "wave_height": round(wave_height_factor, 3),
        "historical_incidents": round(historical_incidents_factor, 3),
        "calculation_method": "weighted_average",
        "data_sources": ["sensors", "historical_data", "weather_forecast"]
    }
    
    # Create new threat score
    new_score = {
        "id": max(s["id"] for s in DUMMY_THREAT_SCORES) + 1,
        "location_name": location_name,
        "latitude": latitude,
        "longitude": longitude,
        "score": round(score, 2),
        "factors": json.dumps(factors),
        "calculated_at": datetime.now().isoformat() + "Z",
        "valid_until": (datetime.now() + timedelta(days=1)).isoformat() + "Z",
        "confidence_level": round(confidence_level, 3)
    }
    
    DUMMY_THREAT_SCORES.append(new_score)
    
    return {
        "message": "Threat score calculated successfully",
        "threat_score": new_score,
        "calculation_details": {
            "method": "weighted_average",
            "factors_used": list(factors.keys()),
            "data_sources": factors["data_sources"]
        }
    }

@router.get("/statistics/summary")
async def get_threat_score_statistics(
    days: int = Query(7, description="Number of days for statistics"),
    db: Session = Depends(get_db)
):
    """
    Get threat score statistics summary.
    
    Args:
        days: Number of days for statistics
        db: Database session
        
    Returns:
        Threat score statistics summary
    """
    # Calculate time threshold
    threshold_time = datetime.now() - timedelta(days=days)
    
    # Filter scores within time range
    recent_scores = [
        s for s in DUMMY_THREAT_SCORES 
        if datetime.fromisoformat(s["calculated_at"].replace("Z", "+00:00")) >= threshold_time
    ]
    
    if not recent_scores:
        return {
            "period_days": days,
            "message": "No threat scores found in specified time range",
            "statistics": {}
        }
    
    # Calculate statistics
    scores = [s["score"] for s in recent_scores]
    confidence_levels = [s["confidence_level"] for s in recent_scores]
    
    stats = {
        "total_scores": len(recent_scores),
        "average_score": round(sum(scores) / len(scores), 2),
        "min_score": min(scores),
        "max_score": max(scores),
        "score_range": max(scores) - min(scores),
        "average_confidence": round(sum(confidence_levels) / len(confidence_levels), 3),
        "risk_distribution": {
            "low_risk": len([s for s in scores if s < 30]),
            "medium_risk": len([s for s in scores if 30 <= s < 70]),
            "high_risk": len([s for s in scores if s >= 70])
        }
    }
    
    return {
        "period_days": days,
        "statistics": stats
    }

@router.get("/trends/analysis")
async def analyze_threat_score_trends(
    location_name: str,
    days: int = Query(30, description="Number of days for trend analysis"),
    db: Session = Depends(get_db)
):
    """
    Analyze threat score trends for a specific location.
    
    Args:
        location_name: Name of the location to analyze
        days: Number of days for analysis
        db: Database session
        
    Returns:
        Trend analysis results
    """
    # Filter scores by location
    location_scores = [s for s in DUMMY_THREAT_SCORES if location_name.lower() in s["location_name"].lower()]
    
    if not location_scores:
        return {
            "location_name": location_name,
            "message": "No threat scores found for this location",
            "trends": {}
        }
    
    # Calculate time threshold
    threshold_time = datetime.now() - timedelta(days=days)
    
    # Filter recent scores
    recent_scores = [
        s for s in location_scores 
        if datetime.fromisoformat(s["calculated_at"].replace("Z", "+00:00")) >= threshold_time
    ]
    
    if len(recent_scores) < 2:
        return {
            "location_name": location_name,
            "message": "Insufficient data for trend analysis",
            "trends": {}
        }
    
    # Sort by calculation time
    recent_scores.sort(key=lambda x: x["calculated_at"])
    
    # Calculate trend
    first_score = recent_scores[0]["score"]
    last_score = recent_scores[-1]["score"]
    
    if last_score > first_score:
        trend = "increasing"
        change_percentage = ((last_score - first_score) / first_score) * 100
    elif last_score < first_score:
        trend = "decreasing"
        change_percentage = ((first_score - last_score) / first_score) * 100
    else:
        trend = "stable"
        change_percentage = 0
    
    # Calculate volatility (standard deviation)
    scores_values = [s["score"] for s in recent_scores]
    mean_score = sum(scores_values) / len(scores_values)
    variance = sum((s - mean_score) ** 2 for s in scores_values) / len(scores_values)
    volatility = variance ** 0.5
    
    return {
        "location_name": location_name,
        "period_days": days,
        "trends": {
            "overall_trend": trend,
            "change_percentage": round(change_percentage, 2),
            "volatility": round(volatility, 2),
            "data_points": len(recent_scores),
            "first_score": first_score,
            "last_score": last_score,
            "score_history": recent_scores
        }
    }

@router.post("/bulk/calculate")
async def calculate_bulk_threat_scores(
    locations: List[Dict[str, Any]],
    db: Session = Depends(get_db)
):
    """
    Calculate threat scores for multiple locations at once.
    
    Args:
        locations: List of location dictionaries with latitude, longitude, and name
        db: Database session
        
    Returns:
        Summary of calculated threat scores
    """
    calculated_scores = []
    
    for location in locations:
        # Calculate threat score for each location
        water_level_factor = random.uniform(0.1, 1.0)
        wind_speed_factor = random.uniform(0.1, 1.0)
        wave_height_factor = random.uniform(0.1, 1.0)
        historical_incidents_factor = random.uniform(0.1, 1.0)
        
        score = (
            water_level_factor * 0.3 +
            wind_speed_factor * 0.25 +
            wave_height_factor * 0.3 +
            historical_incidents_factor * 0.15
        ) * 100
        
        factors = {
            "water_level": round(water_level_factor, 3),
            "wind_speed": round(wind_speed_factor, 3),
            "wave_height": round(wave_height_factor, 3),
            "historical_incidents": round(historical_incidents_factor, 3)
        }
        
        new_score = {
            "id": max(s["id"] for s in DUMMY_THREAT_SCORES) + 1,
            "location_name": location["name"],
            "latitude": location["latitude"],
            "longitude": location["longitude"],
            "score": round(score, 2),
            "factors": json.dumps(factors),
            "calculated_at": datetime.now().isoformat() + "Z",
            "valid_until": (datetime.now() + timedelta(days=1)).isoformat() + "Z",
            "confidence_level": round(random.uniform(0.6, 0.95), 3)
        }
        
        DUMMY_THREAT_SCORES.append(new_score)
        calculated_scores.append(new_score)
    
    return {
        "message": f"Calculated threat scores for {len(locations)} locations",
        "locations_processed": len(locations),
        "calculated_scores": calculated_scores
    }

"""
Database connection and session management for the Coastal Threat Alert System.
This module handles database setup, connection, and session management.
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get database URL from environment, default to SQLite
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./coastal_threat.db")

# Create SQLAlchemy engine
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {}
)

# Create SessionLocal class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create Base class for models
Base = declarative_base()

def create_tables():
    """
    Create all database tables.
    This function is called during application startup.
    """
    try:
        # Import all models to ensure they are registered
        from database_models import GDACSEvent, Sensor, Reading, Incident, Alert, ThreatScore
        
        # Create all tables
        Base.metadata.create_all(bind=engine)
        print("✅ Database tables created successfully")
        print("✅ GDACS events table ready for real disaster data")
        return True
    except Exception as e:
        print(f"❌ Error creating database tables: {e}")
        # For now, just print the error and continue
        # In a real system, you might want to handle this differently
        return False

def get_db():
    """
    Dependency function to get database session.
    This is used by FastAPI endpoints.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """
    Initialize the database with sample data.
    This function can be called to populate the database with initial data.
    """
    try:
        # Create tables first
        create_tables()
        
        # In a real system, you would add sample data here
        # For now, we're using real GDACS data from CSV
        print("✅ Database initialized successfully")
        print("🌊 Ready to load real GDACS disaster data!")
        return True
    except Exception as e:
        print(f"❌ Error initializing database: {e}")
        return False

# Database health check
def check_db_connection():
    """
    Check if database connection is working.
    """
    try:
        with engine.connect() as connection:
            connection.execute("SELECT 1")
        return True
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False

if __name__ == "__main__":
    # Test database connection
    print("Testing database connection...")
    if check_db_connection():
        print("✅ Database connection successful")
        create_tables()
    else:
        print("❌ Database connection failed")

"""
Anomaly detection service for the Coastal Threat Alert System.
This service analyzes sensor data to detect potential threats and anomalies.
"""

import random
from datetime import datetime, timedelta
from typing import List, Dict, Any
from models import Reading, Incident

class AnomalyDetectionService:
    """
    Service for detecting anomalies in sensor data and generating incidents.
    Currently contains dummy logic for demonstration purposes.
    """
    
    def __init__(self):
        """Initialize the anomaly detection service."""
        self.thresholds = {
            'water_level': {'min': 0.5, 'max': 3.0, 'critical': 4.0},
            'wind_speed': {'min': 0, 'max': 25, 'critical': 40},
            'wave_height': {'min': 0.1, 'max': 2.0, 'critical': 4.0},
            'temperature': {'min': 10, 'max': 35, 'critical': 45}
        }
    
    def detect_anomalies(self, readings: List[Reading]) -> List[Dict[str, Any]]:
        """
        Detect anomalies in sensor readings.
        
        Args:
            readings: List of sensor readings to analyze
            
        Returns:
            List of detected anomalies with details
        """
        anomalies = []
        
        for reading in readings:
            # Get threshold for this sensor type
            sensor_type = self._get_sensor_type(reading.sensor_id)
            if sensor_type in self.thresholds:
                threshold = self.thresholds[sensor_type]
                
                # Check for anomalies based on thresholds
                if reading.value < threshold['min']:
                    anomalies.append({
                        'sensor_id': reading.sensor_id,
                        'reading_id': reading.id,
                        'anomaly_type': 'below_minimum',
                        'severity': 'medium',
                        'description': f"{sensor_type} reading {reading.value} is below minimum threshold {threshold['min']}",
                        'timestamp': reading.timestamp
                    })
                
                elif reading.value > threshold['critical']:
                    anomalies.append({
                        'sensor_id': reading.sensor_id,
                        'reading_id': reading.id,
                        'anomaly_type': 'critical_level',
                        'severity': 'critical',
                        'description': f"{sensor_type} reading {reading.value} exceeds critical threshold {threshold['critical']}",
                        'timestamp': reading.timestamp
                    })
                
                elif reading.value > threshold['max']:
                    anomalies.append({
                        'sensor_id': reading.sensor_id,
                        'reading_id': reading.id,
                        'anomaly_type': 'above_maximum',
                        'severity': 'high',
                        'description': f"{sensor_type} reading {reading.value} exceeds maximum threshold {threshold['max']}",
                        'timestamp': reading.timestamp
                    })
        
        return anomalies
    
    def generate_incident(self, anomaly: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate an incident from a detected anomaly.
        
        Args:
            anomaly: Detected anomaly details
            
        Returns:
            Incident data ready for database storage
        """
        # Map anomaly types to incident types
        incident_type_mapping = {
            'below_minimum': 'sensor_malfunction',
            'above_maximum': 'environmental_threat',
            'critical_level': 'emergency_situation'
        }
        
        incident_type = incident_type_mapping.get(anomaly['anomaly_type'], 'unknown_threat')
        
        # Generate dummy coordinates (in real system, these would come from sensor location)
        latitude = 40.7128 + (random.random() - 0.5) * 0.1  # Around NYC
        longitude = -74.0060 + (random.random() - 0.5) * 0.1
        
        return {
            'title': f"{anomaly['anomaly_type'].replace('_', ' ').title()} Detected",
            'description': anomaly['description'],
            'incident_type': incident_type,
            'severity_level': anomaly['severity'],
            'latitude': latitude,
            'longitude': longitude,
            'detected_at': anomaly['timestamp']
        }
    
    def _get_sensor_type(self, sensor_id: int) -> str:
        """
        Get sensor type by sensor ID.
        In a real system, this would query the database.
        
        Args:
            sensor_id: ID of the sensor
            
        Returns:
            Sensor type string
        """
        # Dummy logic - in real system, query database
        sensor_types = ['water_level', 'wind_speed', 'wave_height', 'temperature']
        return sensor_types[sensor_id % len(sensor_types)]
    
    def analyze_trends(self, readings: List[Reading], hours: int = 24) -> Dict[str, Any]:
        """
        Analyze trends in sensor data over a specified time period.
        
        Args:
            readings: List of sensor readings
            hours: Number of hours to analyze
            
        Returns:
            Trend analysis results
        """
        if not readings:
            return {'trend': 'insufficient_data', 'confidence': 0.0}
        
        # Simple trend analysis (dummy logic)
        recent_readings = [r for r in readings if r.timestamp > datetime.now() - timedelta(hours=hours)]
        
        if len(recent_readings) < 2:
            return {'trend': 'insufficient_data', 'confidence': 0.0}
        
        # Calculate simple trend
        values = [r.value for r in recent_readings]
        trend = 'increasing' if values[-1] > values[0] else 'decreasing' if values[-1] < values[0] else 'stable'
        
        # Calculate confidence based on data consistency
        variance = sum((v - sum(values) / len(values)) ** 2 for v in values) / len(values)
        confidence = max(0.1, 1.0 - (variance / 100))
        
        return {
            'trend': trend,
            'confidence': confidence,
            'data_points': len(recent_readings),
            'time_period_hours': hours
        }

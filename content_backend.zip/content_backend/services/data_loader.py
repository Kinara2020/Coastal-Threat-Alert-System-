"""
Data loading service for the Coastal Threat Alert System.
This service handles importing GDACS disaster data from CSV files.
"""

import csv
import pandas as pd
from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from database_models import GDACSEvent, Base
from db import engine
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class GDACSDataLoader:
    """Service for loading GDACS disaster data from CSV files."""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def parse_gdacs_date(self, date_str: str) -> Optional[datetime]:
        """Parse GDACS date format to datetime object."""
        try:
            # GDACS format: "Fri, 29 Aug 2025 16:29:21 GMT"
            if date_str and date_str.strip():
                # Remove GMT and parse
                date_str_clean = date_str.replace(" GMT", "").strip()
                return datetime.strptime(date_str_clean, "%a, %d %b %Y %H:%M:%S")
        except Exception as e:
            logger.warning(f"Could not parse date: {date_str}, error: {e}")
        return None
    
    def extract_threat_level(self, title: str) -> str:
        """Extract threat level from event title."""
        title_lower = title.lower()
        if "red alert" in title_lower:
            return "Red"
        elif "orange alert" in title_lower:
            return "Orange"
        elif "green alert" in title_lower:
            return "Green"
        else:
            return "Unknown"
    
    def extract_population_affected(self, summary: str) -> Optional[int]:
        """Extract population affected from event summary."""
        try:
            # Look for patterns like "1.4 million", "4 thousand", "300"
            import re
            patterns = [
                r'(\d+(?:\.\d+)?)\s*million',
                r'(\d+(?:\.\d+)?)\s*thousand',
                r'(\d+)\s*in\s*MMI',
                r'(\d+)\s*displaced'
            ]
            
            for pattern in patterns:
                match = re.search(pattern, summary, re.IGNORECASE)
                if match:
                    number = float(match.group(1))
                    if "million" in pattern:
                        return int(number * 1000000)
                    elif "thousand" in pattern:
                        return int(number * 1000)
                    else:
                        return int(number)
        except Exception as e:
            logger.warning(f"Could not extract population: {e}")
        return None
    
    def load_gdacs_csv(self, csv_file_path: str) -> Dict[str, Any]:
        """Load GDACS data from CSV file and return statistics."""
        try:
            logger.info(f"Loading GDACS data from: {csv_file_path}")
            
            # Read CSV with pandas for better handling
            df = pd.read_csv(csv_file_path)
            
            # Skip header rows that start with #
            df = df[~df['id'].str.startswith('#', na=False)]
            
            total_loaded = 0
            total_skipped = 0
            errors = []
            
            for _, row in df.iterrows():
                try:
                    # Parse dates
                    from_date = self.parse_gdacs_date(row['from_date'])
                    to_date = self.parse_gdacs_date(row['to_date'])
                    
                    if not from_date or not to_date:
                        logger.warning(f"Skipping row with invalid dates: {row['id']}")
                        total_skipped += 1
                        continue
                    
                    # Create GDACS event
                    gdacs_event = GDACSEvent(
                        id=row['id'],
                        iso3=row['iso3'] if pd.notna(row['iso3']) else None,
                        country=row['country'] if pd.notna(row['country']) else None,
                        title=row['title'],
                        summary=row['summary'],
                        event_type=row['event_type'],
                        severity_unit=row['severity_unit'] if pd.notna(row['severity_unit']) else None,
                        severity_value=float(row['severity_value']) if pd.notna(row['severity_value']) else None,
                        source=row['source'],
                        from_date=from_date,
                        to_date=to_date,
                        link=row['link'],
                        geo_lat=float(row['geo_lat']),
                        geo_long=float(row['geo_long']),
                        gdacs_bbox=row['gdacs_bbox'] if pd.notna(row['gdacs_bbox']) else None,
                        threat_level=self.extract_threat_level(row['title']),
                        population_affected=self.extract_population_affected(row['summary']),
                        economic_impact=None  # Could be enhanced with economic analysis
                    )
                    
                    # Add to database
                    self.db.add(gdacs_event)
                    total_loaded += 1
                    
                except Exception as e:
                    error_msg = f"Error processing row {row.get('id', 'unknown')}: {str(e)}"
                    logger.error(error_msg)
                    errors.append(error_msg)
                    total_skipped += 1
            
            # Commit all changes
            self.db.commit()
            
            logger.info(f"Successfully loaded {total_loaded} GDACS events")
            
            return {
                "total_loaded": total_loaded,
                "total_skipped": total_skipped,
                "errors": errors,
                "success": True
            }
            
        except Exception as e:
            logger.error(f"Error loading GDACS CSV: {e}")
            self.db.rollback()
            return {
                "total_loaded": 0,
                "total_skipped": 0,
                "errors": [str(e)],
                "success": False
            }
    
    def get_gdacs_statistics(self) -> Dict[str, Any]:
        """Get statistics about loaded GDACS data."""
        try:
            total_events = self.db.query(GDACSEvent).count()
            
            # Events by type
            events_by_type = {}
            for event_type in self.db.query(GDACSEvent.event_type.distinct()).all():
                event_type = event_type[0]
                count = self.db.query(GDACSEvent).filter(GDACSEvent.event_type == event_type).count()
                events_by_type[event_type] = count
            
            # Events by country
            events_by_country = {}
            for country in self.db.query(GDACSEvent.country.distinct()).filter(GDACSEvent.country.isnot(None)).all():
                country = country[0]
                count = self.db.query(GDACSEvent).filter(GDACSEvent.country == country).count()
                events_by_country[country] = count
            
            # Events by threat level
            events_by_threat = {}
            for threat_level in self.db.query(GDACSEvent.threat_level.distinct()).filter(GDACSEvent.threat_level.isnot(None)).all():
                threat_level = threat_level[0]
                count = self.db.query(GDACSEvent).filter(GDACSEvent.threat_level == threat_level).count()
                events_by_threat[threat_level] = count
            
            # Recent events (last 7 days)
            recent_date = datetime.utcnow()
            recent_events = self.db.query(GDACSEvent).filter(
                GDACSEvent.from_date >= recent_date
            ).order_by(GDACSEvent.from_date.desc()).limit(10).all()
            
            return {
                "total_events": total_events,
                "by_type": events_by_type,
                "by_country": events_by_country,
                "by_threat_level": events_by_threat,
                "recent_events_count": len(recent_events)
            }
            
        except Exception as e:
            logger.error(f"Error getting GDACS statistics: {e}")
            return {"error": str(e)}
    
    def clear_gdacs_data(self) -> bool:
        """Clear all GDACS data from database."""
        try:
            self.db.query(GDACSEvent).delete()
            self.db.commit()
            logger.info("All GDACS data cleared successfully")
            return True
        except Exception as e:
            logger.error(f"Error clearing GDACS data: {e}")
            self.db.rollback()
            return False

def load_gdacs_data_to_db(csv_file_path: str) -> Dict[str, Any]:
    """Convenience function to load GDACS data directly."""
    from db import SessionLocal
    
    db = SessionLocal()
    try:
        loader = GDACSDataLoader(db)
        result = loader.load_gdacs_csv(csv_file_path)
        return result
    finally:
        db.close()

if __name__ == "__main__":
    # Test the data loader
    result = load_gdacs_data_to_db("ctas.csv")
    print(f"Data loading result: {result}")

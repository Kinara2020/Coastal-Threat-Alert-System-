"""
Main FastAPI application for the Coastal Threat Alert System.
This is the entry point for the API server.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import os
from dotenv import load_dotenv
from db import create_tables, get_db
from database_models import Base
from routes import gdacs  # NEW: Import GDACS routes instead of old dummy routes

load_dotenv()

app = FastAPI(
    title="Coastal Threat Alert System API",
    description="""A comprehensive API for monitoring coastal threats and environmental conditions using real GDACS disaster data.""",
    version="2.0.0",
    contact={"name": "Coastal Threat Alert System Team", "email": "support@coastal-threat.gov"},
    license_info={"name": "MIT", "url": "https://opensource.org/licenses/MIT"}
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include GDACS routes (NEW - replacing old dummy routes)
app.include_router(gdacs.router, prefix="/api/v1")

@app.on_event("startup")
async def startup_event():
    try:
        create_tables()
        print("✅ Database tables created successfully")
        print("✅ Coastal Threat Alert System API started successfully")
        print("🌊 Now using REAL GDACS disaster data instead of dummy data!")
    except Exception as e:
        print(f"❌ Error during startup: {e}")
        raise e

@app.get("/")
async def root():
    """Root endpoint with system information."""
    return {
        "message": "Coastal Threat Alert System API",
        "version": "2.0.0",
        "description": "Real-time coastal threat monitoring using GDACS disaster data",
        "features": [
            "Real GDACS disaster events",
            "Global disaster monitoring",
            "Threat assessment and scoring",
            "Geographic analysis",
            "Real-time alerts"
        ],
        "endpoints": {
            "gdacs": "/api/v1/gdacs/",
            "docs": "/docs",
            "health": "/health",
            "status": "/status"
        }
    }

@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": "2024-01-01T10:00:00Z",
        "service": "Coastal Threat Alert System",
        "version": "2.0.0",
        "database": "connected"
    }

@app.get("/status")
async def status():
    """System status endpoint."""
    return {
        "api_status": "operational",
        "version": "2.0.0",
        "environment": os.getenv("DEBUG", "False").lower() == "true",
        "database_url": os.getenv("DATABASE_URL", "sqlite:///./coastal_threat.db"),
        "features": {
            "gdacs_integration": "active",
            "real_disaster_data": "enabled",
            "threat_scoring": "active",
            "geographic_analysis": "enabled"
        },
        "limits": {
            "max_events_per_request": 1000,
            "max_search_radius_km": 1000,
            "max_pagination_limit": 200
        }
    }

@app.get("/demo")
async def demo():
    """Demo endpoint showing the new GDACS data capabilities."""
    return {
        "message": "Welcome to the NEW Coastal Threat Alert System!",
        "whats_new": [
            "🌊 Real GDACS disaster data instead of dummy data",
            "🌍 Global disaster monitoring (Earthquakes, Wildfires, Floods, Tropical Cyclones)",
            "📊 Advanced filtering and search capabilities",
            "🗺️ Geographic analysis and nearby event detection",
            "📈 Real-time threat assessment and statistics"
        ],
        "try_these_endpoints": [
            "GET /api/v1/gdacs/ - View all disaster events",
            "GET /api/v1/gdacs/types/Earthquake - View earthquakes only",
            "GET /api/v1/gdacs/country/USA - View US events",
            "GET /api/v1/gdacs/statistics - View disaster statistics",
            "GET /api/v1/gdacs/recent - View recent events",
            "POST /api/v1/gdacs/load-data - Load your ctas.csv data"
        ],
        "data_source": "GDACS (Global Disaster Alert and Coordination System)",
        "data_quality": "Real-time, verified disaster alerts from global sources"
    }

@app.exception_handler(404)
async def not_found_handler(request, exc):
    """Custom 404 error handler."""
    return JSONResponse(
        status_code=404,
        content={
            "error": "Endpoint not found",
            "message": "The requested endpoint does not exist",
            "available_endpoints": [
                "/api/v1/gdacs/",
                "/docs",
                "/health",
                "/status",
                "/demo"
            ]
        }
    )

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    """Custom 500 error handler."""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": "Something went wrong on our end",
            "timestamp": "2024-01-01T10:00:00Z"
        }
    )

if __name__ == "__main__":
    import uvicorn
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8001"))  # Changed from 8000 to 8001
    debug = os.getenv("DEBUG", "False").lower() == "true"
    uvicorn.run("main:app", host=host, port=port, reload=debug, log_level="info")
